package ch.makery.address.view;

import ch.makery.address.model.Person;
import ch.makery.address.util.DateUtil;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.scene.control.Alert.AlertType;

public class NewPersonController {

	@FXML
	private TextField firstNameInput;

	@FXML
	private TextField lastNameInput;

	@FXML
	private TextField streetInput;

	@FXML
	private TextField cityInput;

	@FXML
	private TextField postalCodeInput;

	@FXML
	private TextField birthdayInput;

	private Stage dialogStage;
	private Person person;
	private boolean okClicked = false;

	@FXML
	private void initialize(){}

	public void setPerson(Person person)
	{
		this.person = person;

		firstNameInput.setText(person.getFirstName());
		lastNameInput.setText(person.getLastName());
		streetInput.setText(person.getStreet());
		cityInput.setText(person.getCity());
		postalCodeInput.setText(Integer.toString(person.getPostalCode()));
		birthdayInput.setText(DateUtil.format(person.getBirthday()));
	}

	public boolean isOkClicked() {return okClicked;}

	public void setDialogStage(Stage dialogStage) {this.dialogStage = dialogStage;}

	private boolean inputValidator()
	{
		String errorMessage = "";

		if(firstNameInput.getText() == null || firstNameInput.getText().length() == 0)
			errorMessage += "First name field is empty\n";

		if(lastNameInput.getText() == null || lastNameInput.getText().length() == 0)
			errorMessage += "Last name field is empty\n";

		if(streetInput.getText() == null || streetInput.getText().length() == 0)
			errorMessage += "Street field is empty\n";

		if(cityInput.getText() == null || cityInput.getText().length() == 0)
			errorMessage += "City field is empty\n";

		if(postalCodeInput.getText() == null || postalCodeInput.getText().length() == 0)
			errorMessage += "Postal code field is empty\n";
		else
		{
			try{Integer.parseInt(postalCodeInput.getText());}

			catch(NumberFormatException e){errorMessage += "Postal code field must be an integer\n";}
		}
		if(birthdayInput.getText() == null || birthdayInput.getText().length() == 0)
			errorMessage += "Birthday field is empty\n";
		else
		{
			if(!DateUtil.validDate(birthdayInput.getText()))
			{
				errorMessage += "Birthday field is not valid. Use the format dd/mm/yyyy\n";
			}
		}

		if(errorMessage.length() == 0)
			return true;
		else
		{
			Alert errorAlert = new Alert(AlertType.ERROR);
			errorAlert.setTitle("Invalid fields encountered");
			errorAlert.setHeaderText("Please, correct the following fields");
			errorAlert.setContentText(errorMessage);
			errorAlert.showAndWait();
			return false;
		}
	}

	@FXML
	private void handleOk()
	{
		if(inputValidator())
		{
			person.setFirstName(firstNameInput.getText());
			person.setLastName(lastNameInput.getText());
			person.setStreet(streetInput.getText());
			person.setCity(cityInput.getText());
			person.setPostalCode(Integer.parseInt(postalCodeInput.getText()));
			person.setBirthday(DateUtil.parse(birthdayInput.getText()));

			okClicked = true;
			dialogStage.close();
		}
	}

	@FXML
	private void handleCancel() {dialogStage.close();}
}
