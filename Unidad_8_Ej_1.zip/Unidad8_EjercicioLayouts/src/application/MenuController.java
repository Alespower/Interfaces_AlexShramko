package application;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListView;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;
import javafx.scene.control.cell.ComboBoxListCell;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;


public class MenuController {
	
	@FXML
    private ChoiceBox<String> locationChoiceBox;
	@FXML
    private ListView<String> qualificationsList;
	@FXML
    private ComboBox<String> languageComboBox;
	@FXML
    private TreeView<String> inboxTreeView;

	
	ObservableList<String> locations = FXCollections.observableArrayList();
	ObservableList<String> qualificationsVoid = FXCollections.observableArrayList();
	ObservableList<String> qualifications = FXCollections.observableArrayList();
	ObservableList<String> idiomas = FXCollections.observableArrayList();
	
    @FXML
    private void initialize() 
    {
    	
    	//Localizaciones
    	
    	locationChoiceBox.setValue("Value");
    	locations.addAll("New York", "Orlando", "London", "Manchester");
    	locationChoiceBox.setItems(locations);
    	
    	//Cualificaciones
    	
    	for(int i = 0; i < 10; i++)
    	{
    		qualificationsVoid.add("Pick a choice.");
    	}
    	
    	qualifications.addAll("Objects", "Classes", "Functions", "Variables", "Compiler", "Debugger", 
    						  "Projects", "Beans", "Libraries", "Modules", "JARs");
    	
    	qualificationsList.setItems(qualificationsVoid);
    	qualificationsList.setCellFactory(ComboBoxListCell.forListView(qualifications));
    	
    	//Idiomas
    	
    	idiomas.addAll("English", "Spanish", "Ukrainian");
    	languageComboBox.setItems(idiomas);
    	languageComboBox.setValue("Language");
    	
    	//Inbox
    	
     	FileInputStream fis = null;
    	try {
			fis = new FileInputStream("img/Folder.PNG");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
    	
    	ImageView imageView = new ImageView(new Image(fis)); 
    	imageView.setPreserveRatio(true);
    	imageView.setFitHeight(20);
    	
    	TreeItem<String> rootItem = new TreeItem<String>("Inbox", imageView);
    	rootItem.setExpanded(true);
    	inboxTreeView.setRoot(rootItem);
    	
    	
    	List<String> treeListItems = new ArrayList<String>(Arrays.asList("Sales", 
    			"Marketing", "Distribution", "Costs"));
    	
        for (String item : treeListItems) {
            TreeItem<String> treeItem = new TreeItem<String>(item);            
            rootItem.getChildren().add(treeItem);
        }
    	
    }
    
}